package com.example.testing2.Controller;

import com.example.testing2.Model.MenuItem;
import com.example.testing2.Repository.MenuItemRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    // Table elements
    @FXML private TableView<MenuItem> menuTable;
    @FXML private TableColumn<MenuItem, Integer> idCol;
    @FXML private TableColumn<MenuItem, String> nameCol;
    @FXML private TableColumn<MenuItem, Double> priceCol;
    @FXML private TableColumn<MenuItem, Integer> categoryCol;

    // Input fields
    @FXML private TextField nameInput;
    @FXML private TextField priceInput;
    @FXML private TextField categoryInput;

    private MenuItemRepository menuRepo = new MenuItemRepository();
    private ObservableList<MenuItem> menuList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Link table columns to MenuItem variables
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("categoryId"));

        // 2. Load the data
        refreshTable();

        // 3. Make the table clickable! When you click a row, fill the text boxes so you can edit it.
        menuTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                nameInput.setText(newSelection.getName());
                priceInput.setText(String.valueOf(newSelection.getPrice()));
                categoryInput.setText(String.valueOf(newSelection.getCategoryId()));
            }
        });
    }

    private void refreshTable() {
        menuList = FXCollections.observableArrayList(menuRepo.findAll());
        menuTable.setItems(menuList);
    }

    @FXML
    public void onAddClicked(ActionEvent event) {
        try {
            // Read what the user typed
            String name = nameInput.getText();
            double price = Double.parseDouble(priceInput.getText());
            int catId = Integer.parseInt(categoryInput.getText());

            // Create and save to SQLite
            MenuItem newItem = new MenuItem(name, price, catId);
            menuRepo.save(newItem);

            // Clear boxes and refresh table
            clearInputs();
            refreshTable();
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Price and Category must be valid numbers.");
        }
    }

    @FXML
    public void onUpdateClicked(ActionEvent event) {
        MenuItem selected = menuTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Selection Error", "Please select an item from the table to update.");
            return;
        }

        try {
            // Update the selected item's values
            selected.setName(nameInput.getText());
            selected.setPrice(Double.parseDouble(priceInput.getText()));
            selected.setCategoryId(Integer.parseInt(categoryInput.getText()));

            // Send to database
            menuRepo.update(selected);
            refreshTable();
            clearInputs();
            menuTable.getSelectionModel().clearSelection();
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Price and Category must be valid numbers.");
        }
    }

    @FXML
    public void onDeleteClicked(ActionEvent event) {
        MenuItem selected = menuTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Selection Error", "Please select an item from the table to delete.");
            return;
        }

        menuRepo.delete(selected.getId());
        refreshTable();
        clearInputs();
    }

    private void clearInputs() {
        nameInput.clear();
        priceInput.clear();
        categoryInput.clear();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}