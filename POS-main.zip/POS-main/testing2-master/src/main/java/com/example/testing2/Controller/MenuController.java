package com.example.testing2.Controller;

import com.example.testing2.Model.CartItem;
import com.example.testing2.Model.MenuItem;
import com.example.testing2.Repository.MenuItemRepository;
import com.example.testing2.Service.CheckoutService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MenuController implements Initializable {

    // --- GUI Elements ---
    @FXML private ListView<MenuItem> menuListView;
    @FXML private ListView<CartItem> cartListView; // Upgraded to CartItem!
    @FXML private Label totalLabel;
    @FXML private Button inventoryButton; // Matches the ID we just added
    private com.example.testing2.Model.User currentUser; // Store the logged-in user
    @FXML private javafx.scene.control.Button adminMenuButton;
    @FXML private javafx.scene.control.Button recipeButton;

    // --- Services and Data ---
    private MenuItemRepository menuRepo = new MenuItemRepository();
    private CheckoutService checkoutService = new CheckoutService(); // Connects the backend

    private ObservableList<CartItem> cartItems = FXCollections.observableArrayList();
    private double currentTotal = 0.0;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Load the Menu using our new helper method
        refreshMenuList();

        // Link the Cart
        cartListView.setItems(cartItems);
    }

    // --- Add to Cart Logic ---
    @FXML
    public void onMenuItemClicked(MouseEvent event) {
        MenuItem selectedItem = menuListView.getSelectionModel().getSelectedItem();

        if (selectedItem != null) {
            boolean itemExists = false;

            // Loop through the cart to see if the drink is already there
            for (CartItem cartItem : cartItems) {
                if (cartItem.getMenuItem().getId() == selectedItem.getId()) {
                    cartItem.setQuantity(cartItem.getQuantity() + 1); // Stack it!
                    itemExists = true;
                    break;
                }
            }

            // If it's a new drink, add it with a quantity of 1
            if (!itemExists) {
                cartItems.add(new CartItem(selectedItem, 1));
            }

            cartListView.refresh(); // Forces the list to update the "x 2", "x 3" text

            // Update Total
            currentTotal += selectedItem.getPrice();
            totalLabel.setText(String.format("%.2f", currentTotal));
        }
    }

    // --- Checkout Logic ---
    @FXML
    public void onCheckoutClicked(ActionEvent event) {
        // Safety check: Don't checkout an empty cart
        if (cartItems.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Empty Cart", "Please add items to the cart first.");
            return;
        }

        // Call your groupmate's backend! (Assuming userId 1 and "CASH" for the MVP)
        String result = checkoutService.checkoutOrder(new ArrayList<>(cartItems), 1, "CASH");

        // If the backend returns a success message
        if (result.contains("successfully")) {
            showAlert(Alert.AlertType.INFORMATION, "Success", result);

            // Clear the cart for the next customer
            cartItems.clear();
            currentTotal = 0.0;
            totalLabel.setText("0.00");
        } else {
            // If the backend returns an error (like insufficient stock)
            showAlert(Alert.AlertType.ERROR, "Checkout Failed", result);
        }
    }

    // Helper method to create clean pop-up alerts
    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    public void setupUser(com.example.testing2.Model.User user) {
        this.currentUser = user;
        if (!"ADMIN".equalsIgnoreCase(user.getRole())) {
            // ... (your other hidden buttons)
            recipeButton.setVisible(false);
            recipeButton.setManaged(false);
        }
    }
    public void refreshMenuList() {
        List<MenuItem> itemsFromDB = menuRepo.findAll();
        menuListView.setItems(FXCollections.observableArrayList(itemsFromDB));
    }

    @FXML
    public void onCheckInventoryClicked(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/testing2/inventory-view.fxml"));
            javafx.scene.Parent root = loader.load();
            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.setTitle("Inventory Monitor");
            stage.setScene(new javafx.scene.Scene(root, 500, 400));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void onLogoutClicked(javafx.event.ActionEvent event) {
        try {
            // Load the Login screen again
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/com/example/testing2/login-view.fxml"));
            javafx.scene.Parent root = loader.load();

            // Swap the scene back to the login box
            javafx.stage.Stage stage = (javafx.stage.Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Cafe POS - Login");
            stage.setScene(new javafx.scene.Scene(root, 400, 350));
            stage.centerOnScreen();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void onAdminMenuClicked(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/testing2/admin-view.fxml"));
            javafx.scene.Parent root = loader.load();
            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.setTitle("Menu Administration");
            stage.setScene(new javafx.scene.Scene(root, 600, 500));

            // --- THE MAGIC LINE ---
            // When the admin window closes, refresh the POS menu list!
            stage.setOnHidden(e -> refreshMenuList());

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void onRecipeClicked(javafx.event.ActionEvent event) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/com/example/testing2/recipe-view.fxml"));
            javafx.scene.Parent root = loader.load();
            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.setTitle("Recipe Manager");
            stage.setScene(new javafx.scene.Scene(root, 500, 500));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}