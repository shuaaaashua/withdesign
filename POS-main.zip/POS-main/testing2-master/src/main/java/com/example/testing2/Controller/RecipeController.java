package com.example.testing2.Controller;

import com.example.testing2.Model.MenuItem;
import com.example.testing2.Model.MenuItemIngredient;
import com.example.testing2.Repository.MenuItemIngredientRepository;
import com.example.testing2.Repository.MenuItemRepository;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class RecipeController implements Initializable {

    @FXML private ComboBox<MenuItem> menuItemComboBox;
    @FXML private TableView<MenuItemIngredient> recipeTable;
    @FXML private TableColumn<MenuItemIngredient, Integer> mappingIdCol;
    @FXML private TableColumn<MenuItemIngredient, String> ingredientNameCol;
    @FXML private TableColumn<MenuItemIngredient, Double> quantityCol;

    @FXML private TextField ingredientIdInput;
    @FXML private TextField quantityInput;

    private MenuItemRepository menuRepo = new MenuItemRepository();
    private MenuItemIngredientRepository mappingRepo = new MenuItemIngredientRepository();
    private com.example.testing2.Repository.IngredientRepository ingredientRepo = new com.example.testing2.Repository.IngredientRepository();
    private com.example.testing2.Service.IngredientService ingredientService = new com.example.testing2.Service.IngredientService();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Set up table columns
        mappingIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ingredientNameCol.setCellValueFactory(cellData -> {
            int ingId = cellData.getValue().getIngredientId();
            com.example.testing2.Model.Ingredient ingredient = ingredientRepo.findById(ingId);
            String name = (ingredient != null) ? ingredient.getName() : "Unknown ID: " + ingId;
            return new javafx.beans.property.SimpleStringProperty(name);
        });
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantityRequired"));

        // 2. Load the drinks into the ComboBox
        List<MenuItem> allDrinks = menuRepo.findAll();
        menuItemComboBox.setItems(FXCollections.observableArrayList(allDrinks));

        // Format the ComboBox so it shows the Name instead of the raw Object
        menuItemComboBox.setConverter(new StringConverter<MenuItem>() {
            @Override
            public String toString(MenuItem item) {
                return (item != null) ? item.getName() : "";
            }
            @Override
            public MenuItem fromString(String string) { return null; }
        });

        // 3. LISTEN FOR CHANGES: When a new drink is selected, fetch its recipe!
        menuItemComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                refreshRecipeTable(newVal.getId());
            }
        });
    }

    private void refreshRecipeTable(int menuItemId) {
        List<MenuItemIngredient> recipe = mappingRepo.findByMenuItemId(menuItemId);
        recipeTable.setItems(FXCollections.observableArrayList(recipe));
    }

    @FXML
    public void onAddIngredientClicked(ActionEvent event) {
        MenuItem selectedDrink = menuItemComboBox.getSelectionModel().getSelectedItem();

        if (selectedDrink == null) {
            showAlert(Alert.AlertType.WARNING, "Error", "Please select a Menu Item from the dropdown first.");
            return;
        }

        try {
            int ingId = Integer.parseInt(ingredientIdInput.getText());
            double qty = Double.parseDouble(quantityInput.getText());

            // Save the new connection to the database
            MenuItemIngredient newMapping = new MenuItemIngredient(selectedDrink.getId(), ingId, qty);
            mappingRepo.save(newMapping);

            // Refresh the table and clear inputs
            refreshRecipeTable(selectedDrink.getId());
            ingredientIdInput.clear();
            quantityInput.clear();

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Ingredient ID and Quantity must be valid numbers.");
        }
    }

    @FXML
    public void onRemoveIngredientClicked(ActionEvent event) {
        MenuItemIngredient selectedRow = recipeTable.getSelectionModel().getSelectedItem();
        MenuItem selectedDrink = menuItemComboBox.getSelectionModel().getSelectedItem();

        if (selectedRow != null && selectedDrink != null) {
            mappingRepo.delete(selectedRow.getId());
            refreshRecipeTable(selectedDrink.getId());
        } else {
            showAlert(Alert.AlertType.WARNING, "Error", "Please select an ingredient mapping to delete.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
