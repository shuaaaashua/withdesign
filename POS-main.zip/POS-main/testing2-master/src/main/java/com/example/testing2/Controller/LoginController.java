package com.example.testing2.Controller;

import com.example.testing2.Model.User;
import com.example.testing2.Service.UserService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private UserService userService = new UserService();

    @FXML
    public void onLoginClicked(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // 1. Ask the backend if the user exists
        User loggedInUser = userService.login(username, password);

        if (loggedInUser != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/testing2/hello-view.fxml"));
                Parent root = loader.load();

                // NEW STEP: Grab the MenuController and pass the user into it!
                MenuController menuController = loader.getController();
                menuController.setupUser(loggedInUser);

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setTitle("Cafe POS - Cashier: " + loggedInUser.getUsername()); // Show their name!
                stage.setScene(new Scene(root, 900, 600));
                stage.centerOnScreen();

            } catch (IOException e) {
                e.printStackTrace();
                errorLabel.setText("Error loading main screen.");
            }
        }
    }
}
