package com.example.testing2.Controller;

import com.example.testing2.Model.Ingredient;
import com.example.testing2.Service.IngredientService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.ResourceBundle;

public class InventoryController implements Initializable {

    @FXML private TableView<Ingredient> inventoryTable;
    @FXML private TableColumn<Ingredient, String> nameCol;
    @FXML private TableColumn<Ingredient, Double> stockCol;
    @FXML private TableColumn<Ingredient, Double> criticalCol;

    private IngredientService ingredientService = new IngredientService();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // 1. Setup the columns to match the Ingredient Model variables
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stockQuantity"));
        criticalCol.setCellValueFactory(new PropertyValueFactory<>("criticalLevel"));

        // 2. Add "Conditional Formatting" to highlight low stock in RED
        stockCol.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item.toString());
                    Ingredient rowData = getTableView().getItems().get(getIndex());
                    if (item <= rowData.getCriticalLevel()) {
                        setTextFill(Color.RED); // Highlight danger!
                        setStyle("-fx-font-weight: bold;");
                    } else {
                        setTextFill(Color.GREEN);
                        setStyle("");
                    }
                }
            }
        });

        // 3. Fill the table with data
        inventoryTable.setItems(FXCollections.observableArrayList(ingredientService.getAllIngredients()));
    }
}
