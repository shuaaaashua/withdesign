module com.example.testing2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.testing2 to javafx.fxml;
    opens com.example.testing2.Model to javafx.base;
    exports com.example.testing2;
    exports com.example.testing2.Controller;
    opens com.example.testing2.Controller to javafx.fxml;
}